# print("Hello, world!")
# print("Python has three numeric types: int, float, and complex")
# myvalue=1
# print(myvalue)
# print(type(myvalue))
# print(str(myvalue) + " is of the data type" + str(type(myvalue)))
# myvalue=5j
# print(myvalue)
# print(type(myvalue))
# print(str(myvalue) + " is of the data type" + str(type(myvalue)))
# myvalue=True
# print(myvalue)
# print(type(myvalue))
# print(str(myvalue) + " is of the data type" + str(type(myvalue)))
# myvalue=False
# print(myvalue)
# print(type(myvalue))
# print(str(myvalue) + " is of the data type" + str(type(myvalue)))
# mystring="this is a string"
# print(mystring)
# print(type(mystring))
# print(mystring + " is of the data type " + str(type(mystring)))


# firstString = "water"
# seconedString = "fall"
# thirdString = firstString + seconedString
# print(thirdString)

# name = input("what is your name?")
# print(name)

# color = input("What is your favorite color? ")
# animal = input("what is your favorite animal? ")
# print("{}, you like a {} {}!".format(name,color,animal))
# print("{}, you like a {} {}!".format(name,color,animal))

# myFruitList = ["apple", "banana", "cherry"]
# print(myFruitList)
# print(type(myFruitList))
# print(myFruitList[0])
# print(myFruitList[1])
# print(myFruitList[2])
# myFruitList[2] = "Orange"
# print(myFruitList)

myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])

myFavoriteFruitDictionary = {
"Akua" : "apple",
"Saanvi" : "banana",
"Paulo" : "Pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])




